/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package hospitalswing.vista;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class AdmisionFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AdmisionFrame.class.getName());

        private static final String[] AREAS = {
        "Medicina General", "Pediatría", "Ginecología", "Traumatología", "Consulta Externa"};
    private static final String[] NIVELES = {
        "Rojo - Crítico", "Naranja - Emergencia", "Amarillo - Urgente", "Verde - Menos urgente"};
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private DefaultTableModel modelo;
    private int contador = 1;                            // ID autoincremental en memoria

    public AdmisionFrame(String usuario) {
        initComponents();
        lblUsuario.setText("Usuario: " + usuario + "   ");
        configurarTabla();
        actualizarDetalle();
        setSize(1200, 650);
        setLocationRelativeTo(null);
    }

    // ---------- JTable ----------
    private void configurarTabla() {
        modelo = new DefaultTableModel(new String[]{"ID", "Tipo", "Paciente", "DPI", "Edad",
                "Teléfono", "Área / Nivel", "Prioridad", "Ingreso"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int c) {
                return (c == 0 || c == 4 || c == 7) ? Integer.class : String.class;
            }
        };
        tblPacientes.setModel(modelo);
        tblPacientes.setRowHeight(30);
        tblPacientes.setAutoCreateRowSorter(true);       // clic en el encabezado para ordenar

        // Columna Prioridad con colores de semáforo
        tblPacientes.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer() {
            { setHorizontalAlignment(CENTER); }
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                           boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                comp.setFont(comp.getFont().deriveFont(Font.BOLD));
                if (!sel) {
                    switch (String.valueOf(v)) {
                        case "1": comp.setForeground(new Color(0xC62828)); break;
                        case "2": comp.setForeground(new Color(0xEF6C00)); break;
                        case "3": comp.setForeground(new Color(0xB78103)); break;
                        case "4": comp.setForeground(new Color(0x2E7D32)); break;
                        default:  comp.setForeground(Color.GRAY);
                    }
                }
                return comp;
            }
        });
    }

    // ---------- JComboBox dependiente ----------
    private void actualizarDetalle() {
        boolean urgencia = cmbTipo.getSelectedIndex() == 1;
        lblDetalle.setText(urgencia ? "Nivel de urgencia (triage)" : "Área");
        cmbDetalle.setModel(new DefaultComboBoxModel<String>(urgencia ? NIVELES : AREAS));
    }

    // ---------- Guardar con protección estricta (try-catch) ----------
    private void guardar() {
        try {
            String nombre   = txtNombre.getText().trim();
            String apellido = txtApellido.getText().trim();
            String dpi      = txtDpi.getText().trim();
            String telefono = txtTelefono.getText().trim();
            String motivo   = txtMotivo.getText().trim();
            int edad = Integer.parseInt(txtEdad.getText().trim());   // puede lanzar NumberFormatException

            if (!nombre.matches("[\\p{L} ]{2,50}"))
                throw new IllegalArgumentException("El nombre solo debe tener letras (2 a 50 caracteres).");
            if (!apellido.matches("[\\p{L} ]{2,50}"))
                throw new IllegalArgumentException("El apellido solo debe tener letras (2 a 50 caracteres).");
            if (!dpi.matches("\\d{13}"))
                throw new IllegalArgumentException("El DPI debe tener exactamente 13 dígitos.");
            if (edad < 0 || edad > 120)
                throw new IllegalArgumentException("La edad debe estar entre 0 y 120 años.");
            if (!telefono.matches("\\d{8}"))
                throw new IllegalArgumentException("El teléfono debe tener 8 dígitos.");
            if (motivo.length() < 3)
                throw new IllegalArgumentException("Describa el motivo de consulta.");

            boolean urgencia = cmbTipo.getSelectedIndex() == 1;
            String detalle = (String) cmbDetalle.getSelectedItem();
            int prioridad = urgencia ? cmbDetalle.getSelectedIndex() + 1 : 5;   // Rojo=1 ... Verde=4, General=5

            modelo.addRow(new Object[]{
                contador++, urgencia ? "Urgencia" : "General", nombre + " " + apellido,
                dpi, edad, telefono, detalle, prioridad, LocalDateTime.now().format(FORMATO)
            });

            JOptionPane.showMessageDialog(this, "Ingreso registrado: " + nombre + " " + apellido,
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
            limpiar();

        } catch (NumberFormatException ex) {
            error("La edad debe ser un número entero (solo dígitos).");
        } catch (IllegalArgumentException ex) {
            error(ex.getMessage());
        } catch (Exception ex) {
            error("Error inesperado: " + ex.getMessage());
        }
    }

    private void limpiar() {
        txtNombre.setText(""); txtApellido.setText(""); txtDpi.setText("");
        txtEdad.setText(""); txtTelefono.setText(""); txtMotivo.setText("");
        cmbTipo.setSelectedIndex(0);
        txtNombre.requestFocus();
    }

    private void error(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Dato inválido", JOptionPane.WARNING_MESSAGE);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHeader = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        btnCerrarSesion = new javax.swing.JButton();
        pnlFormulario = new javax.swing.JPanel();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblApellido = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        lblDpi = new javax.swing.JLabel();
        txtDpi = new javax.swing.JTextField();
        lblEdad = new javax.swing.JLabel();
        txtEdad = new javax.swing.JTextField();
        lblTelefono = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        lblMotivo = new javax.swing.JLabel();
        txtMotivo = new javax.swing.JTextField();
        lblTipo = new javax.swing.JLabel();
        cmbTipo = new javax.swing.JComboBox<>();
        lblDetalle = new javax.swing.JLabel();
        cmbDetalle = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        scrollTabla = new javax.swing.JScrollPane();
        tblPacientes = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Hospital - Admisión de pacientes");

        pnlHeader.setBackground(new java.awt.Color(11, 93, 122));
        pnlHeader.setPreferredSize(new java.awt.Dimension(100, 56));
        pnlHeader.setLayout(new java.awt.BorderLayout());

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setText(" Admisión de pacientes");
        pnlHeader.add(lblTitulo, java.awt.BorderLayout.LINE_START);

        lblUsuario.setForeground(new java.awt.Color(255, 255, 255));
        lblUsuario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        pnlHeader.add(lblUsuario, java.awt.BorderLayout.CENTER);

        btnCerrarSesion.setText("Cerrar sesión");
        btnCerrarSesion.addActionListener(this::btnCerrarSesionActionPerformed);
        pnlHeader.add(btnCerrarSesion, java.awt.BorderLayout.LINE_END);

        getContentPane().add(pnlHeader, java.awt.BorderLayout.PAGE_START);

        pnlFormulario.setBorder(javax.swing.BorderFactory.createEmptyBorder(16, 1, 1, 1));
        pnlFormulario.setPreferredSize(new java.awt.Dimension(340, 620));
        pnlFormulario.setLayout(new java.awt.GridLayout(18, 1, 0, 2));

        lblNombre.setText("Nombres");
        pnlFormulario.add(lblNombre);

        txtNombre.addActionListener(this::txtNombreActionPerformed);
        pnlFormulario.add(txtNombre);

        lblApellido.setText("Apellidos");
        pnlFormulario.add(lblApellido);
        pnlFormulario.add(txtApellido);

        lblDpi.setText("DPI (13 dígitos)");
        pnlFormulario.add(lblDpi);
        pnlFormulario.add(txtDpi);

        lblEdad.setText("Edad");
        pnlFormulario.add(lblEdad);
        pnlFormulario.add(txtEdad);

        lblTelefono.setText("Teléfono (8 dígitos)");
        pnlFormulario.add(lblTelefono);
        pnlFormulario.add(txtTelefono);

        lblMotivo.setText("Motivo de consulta");
        pnlFormulario.add(lblMotivo);
        pnlFormulario.add(txtMotivo);

        lblTipo.setText("Tipo de atención");
        pnlFormulario.add(lblTipo);

        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Consulta general", "Urgencia" }));
        cmbTipo.addActionListener(this::cmbTipoActionPerformed);
        pnlFormulario.add(cmbTipo);

        lblDetalle.setText("Detalle");
        pnlFormulario.add(lblDetalle);

        cmbDetalle.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        pnlFormulario.add(cmbDetalle);

        btnGuardar.setBackground(new java.awt.Color(11, 93, 122));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar Ingreso");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        pnlFormulario.add(btnGuardar);

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(this::btnLimpiarActionPerformed);
        pnlFormulario.add(btnLimpiar);

        getContentPane().add(pnlFormulario, java.awt.BorderLayout.LINE_START);

        tblPacientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        scrollTabla.setViewportView(tblPacientes);

        getContentPane().add(scrollTabla, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        guardar();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
       limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void cmbTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTipoActionPerformed
       actualizarDetalle();
    }//GEN-LAST:event_cmbTipoActionPerformed

    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
        dispose();
        new LoginFrame().setVisible(true);
        
    }//GEN-LAST:event_btnCerrarSesionActionPerformed
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrarSesion;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<String> cmbDetalle;
    private javax.swing.JComboBox<String> cmbTipo;
    private javax.swing.JLabel lblApellido;
    private javax.swing.JLabel lblDetalle;
    private javax.swing.JLabel lblDpi;
    private javax.swing.JLabel lblEdad;
    private javax.swing.JLabel lblMotivo;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblTelefono;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPanel pnlFormulario;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JScrollPane scrollTabla;
    private javax.swing.JTable tblPacientes;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtDpi;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtMotivo;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
