package hospitalswing;

import hospitalswing.vista.LoginFrame;

public class HospitalSwing {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}