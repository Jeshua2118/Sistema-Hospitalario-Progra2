package com.umg.sistemahospitalarioumg;

public class Paciente {

    private String nombre;
    private String dpi;
    private String tipoAtencion;

    public Paciente(String nombre, String dpi,
                    String tipoAtencion) {
        this.nombre = nombre;
        this.dpi = dpi;
        this.tipoAtencion = tipoAtencion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDpi() {
        return dpi;
    }

    public String getTipoAtencion() {
        return tipoAtencion;
    }

    @Override
    public String toString() {
        return nombre + "\nDPI: " + dpi +
                "\nAtención: " + tipoAtencion;
    }
}
