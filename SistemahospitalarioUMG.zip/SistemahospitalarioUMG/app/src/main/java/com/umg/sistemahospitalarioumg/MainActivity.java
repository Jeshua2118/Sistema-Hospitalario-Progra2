package com.umg.sistemahospitalarioumg;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private EditText etUsuario, etPassword;
    private Button btnIngresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsuario = findViewById(R.id.etUsuario);
        etPassword = findViewById(R.id.etPassword);
        btnIngresar = findViewById(R.id.btnIngresar);

        btnIngresar.setOnClickListener(v -> {
            String usuario = etUsuario.getText().toString().trim();
            String password = etPassword.getText().toString();

            if (usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Complete todos los campos",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Credenciales SOLO para pruebas locales.
            if (usuario.equals("admin") &&
                    password.equals("admin123")) {

                Intent intent = new Intent(
                        MainActivity.this,
                        DirectorioActivity.class
                );
                startActivity(intent);
                finish();

            } else {
                Toast.makeText(this,
                        "Credenciales incorrectas",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
