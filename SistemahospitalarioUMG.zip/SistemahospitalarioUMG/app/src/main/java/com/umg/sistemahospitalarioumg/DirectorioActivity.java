package com.umg.sistemahospitalarioumg;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class DirectorioActivity extends Activity {

    private ListView lista;
    private ArrayList<Paciente> pacientes;
    private ArrayAdapter<Paciente> adapter;

    private static final String URL_API =
            "http://10.0.2.2/Hospital_api/obtener_pacientes.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_directorio);

        lista = findViewById(R.id.listaPacientes);
        Button salir = findViewById(R.id.btnSalir);

        pacientes = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                R.layout.simple_list_item_1,
                android.R.id.text1,
                pacientes
        );

        lista.setAdapter(adapter);

        cargarPacientes();

        salir.setOnClickListener(v -> {
            Intent intent = new Intent(
                    DirectorioActivity.this,
                    MainActivity.class
            );

            startActivity(intent);
            finish();
        });
    }

    private void cargarPacientes() {

        new Thread(() -> {

            HttpURLConnection conexion = null;

            try {

                android.util.Log.e("HOSPITAL_API", "URL UTILIZADA: " + URL_API);

                URL url = new URL(URL_API);

                java.net.Proxy proxy = java.net.Proxy.NO_PROXY;

                conexion = (HttpURLConnection) url.openConnection(proxy);

                conexion.setRequestMethod("GET");
                conexion.setConnectTimeout(5000);
                conexion.setReadTimeout(5000);

                int codigo = conexion.getResponseCode();

                if (codigo != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Error HTTP: " + codigo);
                }

                BufferedReader lector = new BufferedReader(
                        new InputStreamReader(
                                conexion.getInputStream(),
                                "UTF-8"
                        )
                );

                StringBuilder respuesta = new StringBuilder();
                String linea;

                while ((linea = lector.readLine()) != null) {
                    respuesta.append(linea);
                }

                lector.close();

                JSONArray datos = new JSONArray(respuesta.toString());

                ArrayList<Paciente> nuevosPacientes =
                        new ArrayList<>();

                for (int i = 0; i < datos.length(); i++) {

                    JSONObject objeto = datos.getJSONObject(i);

                    String nombre = objeto.optString("nombre", "");
                    String apellido = objeto.optString("apellido", "");
                    String dpi = objeto.optString("dpi", "");
                    String urgencia = objeto.optString("urgencia", "");

                    Paciente paciente = new Paciente(
                            (nombre + " " + apellido).trim(),
                            dpi,
                            urgencia
                    );

                    nuevosPacientes.add(paciente);
                }

                runOnUiThread(() -> {

                    pacientes.clear();
                    pacientes.addAll(nuevosPacientes);

                    adapter.notifyDataSetChanged();

                    Toast.makeText(
                            DirectorioActivity.this,
                            "Pacientes cargados correctamente",
                            Toast.LENGTH_SHORT
                    ).show();
                });

            } catch (Exception e) {
                android.util.Log.e("HOSPITAL_API", "Error al cargar pacientes", e);
                runOnUiThread(() -> {

                    Toast.makeText(
                            DirectorioActivity.this,
                            "Error al cargar pacientes: " + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });

            } finally {

                if (conexion != null) {
                    conexion.disconnect();
                }
            }

        }).start();
    }
}