package com.umg.sistemahospitalarioumg;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MenuActivity extends Activity {

    private Button btnIrDirectorio, btnIrRegistro, btnCerrarSesionMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btnIrDirectorio = findViewById(R.id.btnIrDirectorio);
        btnIrRegistro = findViewById(R.id.btnIrRegistro);
        btnCerrarSesionMenu = findViewById(R.id.btnCerrarSesionMenu);

        // Ir al listado de pacientes
        btnIrDirectorio.setOnClickListener(v -> {
            startActivity(new Intent(MenuActivity.this, DirectorioActivity.class));
        });

        // Ir al formulario de registro
        btnIrRegistro.setOnClickListener(v -> {
            startActivity(new Intent(MenuActivity.this, RegistroActivity.class));
        });

        // Cerrar sesión y regresar al login
        btnCerrarSesionMenu.setOnClickListener(v -> {
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}