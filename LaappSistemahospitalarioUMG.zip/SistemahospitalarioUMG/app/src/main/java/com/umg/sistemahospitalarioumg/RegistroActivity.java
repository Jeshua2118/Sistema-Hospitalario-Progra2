package com.umg.sistemahospitalarioumg;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class RegistroActivity extends AppCompatActivity {

    private EditText etNombre, etApellido, etDpi, etEdad, etTelefono, etMotivo, etUrgencia;
    private Button btnGuardarPaciente, btnRegresarMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        etDpi = findViewById(R.id.etDpi);
        etEdad = findViewById(R.id.etEdad);
        etTelefono = findViewById(R.id.etTelefono);
        etMotivo = findViewById(R.id.etMotivo);
        etUrgencia = findViewById(R.id.etUrgencia);
        btnGuardarPaciente = findViewById(R.id.btnGuardarPaciente);
        btnRegresarMenu = findViewById(R.id.btnRegresarMenu);

        // Botón para guardar paciente en MySQL
        btnGuardarPaciente.setOnClickListener(v -> registrarPacienteServidor());

        // Botón para regresar al menú principal de forma limpia
        btnRegresarMenu.setOnClickListener(v -> {
            Intent intent = new Intent(RegistroActivity.this, MenuActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
    }

    private void registrarPacienteServidor() {
        String nombre = etNombre.getText().toString().trim();
        String apellido = etApellido.getText().toString().trim();
        String dpi = etDpi.getText().toString().trim();
        String edad = etEdad.getText().toString().trim();
        String telefono = etTelefono.getText().toString().trim();
        String motivo = etMotivo.getText().toString().trim();
        String urgencia = etUrgencia.getText().toString().trim();

        if (nombre.isEmpty() || apellido.isEmpty() || dpi.isEmpty()) {
            Toast.makeText(this, "Por favor completa los campos principales", Toast.LENGTH_SHORT).show();
            return;
        }

        String urlString = "http://192.168.1.11/Hospital_api/insertar_paciente.php";

        new Thread(() -> {
            HttpURLConnection conexion = null;
            try {
                URL url = new URL(urlString);
                conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setConnectTimeout(5000);
                conexion.setReadTimeout(5000);


                String datosPost = "nombre=" + URLEncoder.encode(nombre, "UTF-8") +
                        "&apellido=" + URLEncoder.encode(apellido, "UTF-8") +
                        "&dpi=" + URLEncoder.encode(dpi, "UTF-8") +
                        "&edad=" + URLEncoder.encode(edad, "UTF-8") +
                        "&telefono=" + URLEncoder.encode(telefono, "UTF-8") +
                        "&motivo=" + URLEncoder.encode(motivo, "UTF-8") +
                        "&urgencia=" + URLEncoder.encode(urgencia, "UTF-8");

                OutputStream os = conexion.getOutputStream();
                os.write(datosPost.getBytes("UTF-8"));
                os.flush();
                os.close();

                int responseCode = conexion.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder respuesta = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        respuesta.append(linea);
                    }
                    reader.close();

                    runOnUiThread(() -> {
                        Toast.makeText(RegistroActivity.this, "¡Paciente registrado con éxito!", Toast.LENGTH_LONG).show();
                        finish();
                    });
                } else {
                    runOnUiThread(() -> Toast.makeText(RegistroActivity.this, "Error en el servidor", Toast.LENGTH_SHORT).show());
                }

            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(RegistroActivity.this, "Excepción: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (conexion != null) {
                    conexion.disconnect();
                }
            }
        }).start();
    }
}