package com.umg.sistemahospitalarioumg;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class DirectorioActivity extends AppCompatActivity {

    private static final String TAG = "DIRECTORIO_APP";
    private ListView listViewPacientes;
    private ArrayList<String> listaDatosPacientes;
    private ArrayAdapter<String> adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directorio);

        Log.d(TAG, "onCreate: Inicializando DirectorioActivity");

        listViewPacientes = findViewById(R.id.listViewPacientes);
        if (listViewPacientes == null) {
            Log.e(TAG, "ERROR CRÍTICO: listViewPacientes es NULL. Revisa el ID en el XML.");
        }

        // --- LÓGICA DE CIERRE DE SESIÓN CORREGIDA ---
        Button btnCerrarSesion = findViewById(R.id.btnCerrarSesion);
        if (btnCerrarSesion != null) {
            btnCerrarSesion.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // CAMBIA "MainActivity.class" si tu pantalla de login se llama diferente (ej: LoginActivity.class)
                    Intent intent = new Intent(DirectorioActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }
            });
        }
        // ---------------------------------------------

        listaDatosPacientes = new ArrayList<>();
        obtenerPacientesDesdeServidor();
    }

    private void obtenerPacientesDesdeServidor() {
        String urlString = "http://192.168.1.11/Hospital_api/obtener_pacientes.php";
        Log.d(TAG, "Iniciando conexión a la URL: " + urlString);

        new Thread(new Runnable() {
            @Override
            public void run() {
                StringBuilder respuesta = new StringBuilder();
                HttpURLConnection conexion = null;
                try {
                    URL url = new URL(urlString);
                    conexion = (HttpURLConnection) url.openConnection();
                    conexion.setRequestMethod("GET");

                    conexion.setConnectTimeout(5000);
                    conexion.setReadTimeout(5000);

                    Log.d(TAG, "Abriendo conexión HTTP...");
                    conexion.connect();

                    int responseCode = conexion.getResponseCode();
                    Log.d(TAG, "¡Conexión exitosa! Código HTTP: " + responseCode);

                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                        String linea;
                        while ((linea = reader.readLine()) != null) {
                            respuesta.append(linea);
                        }
                        reader.close();

                        Log.d(TAG, "JSON recibido crudo: " + respuesta.toString());

                        final ArrayList<String> tempLista = new ArrayList<>();
                        JSONArray jsonArray = new JSONArray(respuesta.toString());
                        Log.d(TAG, "Cantidad de pacientes en el JSON: " + jsonArray.length());

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject objeto = jsonArray.getJSONObject(i);
                            String nombre = objeto.optString("nombre", "Sin nombre");
                            String apellido = objeto.optString("apellido", "");
                            String motivo = objeto.optString("motivo", "Sin motivo");

                            tempLista.add("Paciente: " + nombre + " " + apellido + "\nMotivo: " + motivo);
                        }

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                listaDatosPacientes.clear();
                                listaDatosPacientes.addAll(tempLista);

                                adaptador = new ArrayAdapter<>(DirectorioActivity.this, android.R.layout.simple_list_item_1, listaDatosPacientes);
                                listViewPacientes.setAdapter(adaptador);
                                Log.d(TAG, "¡Adaptador asignado exitosamente al ListView!");
                            }
                        });
                    } else {
                        Log.e(TAG, "Servidor respondió con código de error HTTP: " + responseCode);
                    }

                } catch (Exception e) {
                    Log.e(TAG, "EXCEPCIÓN CAPTURADA EN RED: " + e.getMessage(), e);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(DirectorioActivity.this, "Error de red: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                } finally {
                    if (conexion != null) {
                        conexion.disconnect();
                    }
                }
            }
        }).start();
    }
}